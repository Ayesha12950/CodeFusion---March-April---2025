import PasswordGenerator from "../components/PasswordGenerator";

const HomePage = () => {
  return (
    <div>
      <PasswordGenerator />
    </div>
  );
};

export default HomePage;
